/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tugasproject1;
import javax.swing.*;

public class Sejarah extends JFrame {
    private JTextArea teksarea2;
  
    public Sejarah() {
        initComponents();
        txtarea2.setText("Universitas Cokroaminoto Palopo (UNCP) \n" +
                         "merupakan salah satu perguruan tinggi \n" +
                         "ternama di Kota Palopo, Provinsi Sulawesi \n" +
                         "Selatan.Universitas yang populer dengan \n" +
                         "nama Uncokro Palopo berdiri sejak 1 Maret\n" +
                         "1967. Dikutip dari situs, uncp.ac.id, Sabtu \n" +
                         "(17/10/2020), perguruan tinggi ini pada \n" +
"awalnya dibina oleh Yayasan Perguruan \n" +
"Tinggi Cokroaminoto Makassar.\n" +
"Berdasarkan Akte Notaris Nomor: 33 \n" +
"tanggal 16 Mei 1986 oleh Notaris MG \n" +
"Ohorella. Dengan nama Fakultas Keguruan\n" +
"dan Ilmu Pendidikan (FKIP) Universitas \n" +
"Cokroaminoto Makassar filial Pinrang.Yang \n" +
"selanjutnya pada tanggal 24 Januari 1976 \n" +
"diubah menjadi Sekolah Tinggi Keguruan \n" +
"dan Ilmu Pendidikan (STKIP) Cokroaminoto \n" +
"Palopo.\n" +
"Berdasarkan Surat Keputusan Koordinator \n" +
"Kopertis Wilayah VII Sulawesi, Maluku, dan\n" +
"Irian Jaya Nomor: II tahun 1976 tanggal 24\n" +
"Januari 1976. Pada tahun 1995, Yayasan \n" +
"Perguruan Tinggi Cokroaminoto Palopo \n" +
"juga membuka Sekolah Tinggi Ilmu \n" +
"Pertanian (STIPER) Cokroaminoto Palopo.\n" +
"Berdasarkan Surat Keputusan Menteri \n" +
"Pendidikan dan Kebudayaan Nomor: 014/\n" +
"D/O/1995 tanggal 23 Februari 1995.\n" +
"Dalam perkembangan selanjutnya, yakni \n" +
"pada tahun 2005, STKIP Cokroaminoto \n" +
"Palopo dan STIPER Cokroaminoto Palopo \n" +
"bergabung.Lalu berubah bentuk menjadi \n" +
"Universitas Cokroaminoto Palopo \n" +
"berdasarkan Surat Keputusan Menteri \n" +
"Pendidikan Nasional Republik Indonesia \n" +
"Nomor 95/D/O/2005 tanggal 6 Juli 2005.\n" +
"Saat ini, UNCP terdiri dari empat Fakultas, \n" +
"13 Program Studi, dan satu program \n" +
"Pascasarjana.");
        txtarea2.setEditable(false);
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtarea2 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem13 = new javax.swing.JMenuItem();
        jMenuItem14 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();
        jMenuItem15 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 241, 202));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "COKROAMINOTO PALOPO", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Historic", 1, 12))); // NOI18N

        txtarea2.setBackground(new java.awt.Color(255, 241, 202));
        txtarea2.setColumns(20);
        txtarea2.setRows(5);
        txtarea2.setText("Universitas Cokroaminoto Palopo (UNCP) \nmerupakan salah satu perguruan tinggi \nternama di Kota Palopo, Provinsi Sulawesi \nSelatan.Universitas yang populer dengan \nnama Uncokro Palopo berdiri sejak 1 Maret\n1967. Dikutip dari situs, uncp.ac.id, Sabtu \n(17/10/2020), perguruan tinggi ini pada \nawalnya dibina oleh Yayasan Perguruan \nTinggi Cokroaminoto Makassar.\nBerdasarkan Akte Notaris Nomor: 33 \ntanggal 16 Mei 1986 oleh Notaris MG \nOhorella. Dengan nama Fakultas Keguruan\ndan Ilmu Pendidikan (FKIP) Universitas \nCokroaminoto Makassar filial Pinrang.Yang \nselanjutnya pada tanggal 24 Januari 1976 \ndiubah menjadi Sekolah Tinggi Keguruan \ndan Ilmu Pendidikan (STKIP) Cokroaminoto \nPalopo.\nBerdasarkan Surat Keputusan Koordinator \nKopertis Wilayah VII Sulawesi, Maluku, dan\nIrian Jaya Nomor: II tahun 1976 tanggal 24\nJanuari 1976. Pada tahun 1995, Yayasan \nPerguruan Tinggi Cokroaminoto Palopo \njuga membuka Sekolah Tinggi Ilmu \nPertanian (STIPER) Cokroaminoto Palopo.\nBerdasarkan Surat Keputusan Menteri \nPendidikan dan Kebudayaan Nomor: 014/\nD/O/1995 tanggal 23 Februari 1995.\nDalam perkembangan selanjutnya, yakni \npada tahun 2005, STKIP Cokroaminoto \nPalopo dan STIPER Cokroaminoto Palopo \nbergabung.Lalu berubah bentuk menjadi \nUniversitas Cokroaminoto Palopo \nberdasarkan Surat Keputusan Menteri \nPendidikan Nasional Republik Indonesia \nNomor 95/D/O/2005 tanggal 6 Juli 2005.\nSaat ini, UNCP terdiri dari empat Fakultas, \n13 Program Studi, dan satu program \nPascasarjana.\n\n\n\n\n\n\n\n");
        txtarea2.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtarea2AncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane2.setViewportView(txtarea2);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tugasproject1/uncp-juara-1-se-palopo (1) (8).jpg"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 256, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jMenu1.setText("beranda");
        jMenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu1ActionPerformed(evt);
            }
        });

        jMenuItem11.setText("Exit");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem11);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Informasi Akademik");

        jMenuItem2.setText("Kalender Akademik");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem2);

        jMenuItem1.setText("Jadwal Kuliah");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem1);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Profil Kampus");

        jMenuItem3.setText("Sejarah");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem3);

        jMenuItem13.setText("Fasilitas Kampus");
        jMenuItem13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem13ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem13);

        jMenuItem14.setText("Visi Misi");
        jMenuItem14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem14ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem14);

        jMenuItem12.setText("Wisudawan terbaik");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem12);

        jMenuItem15.setText("Falkultas");
        jMenuItem15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem15ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem15);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem11ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jMenuItem11ActionPerformed

    private void jMenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu1ActionPerformed

    }//GEN-LAST:event_jMenu1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        Kamik newWin =  new Kamik ();
        newWin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        Jatkul newWin =  new Jatkul ();
        newWin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        Sejarah newWin =  new Sejarah();
        newWin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem13ActionPerformed
        Fasilitas newWin =  new Fasilitas ();
        newWin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem13ActionPerformed

    private void jMenuItem14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem14ActionPerformed
        VisiMisi newWin =  new VisiMisi ();
        newWin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem14ActionPerformed

    private void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem12ActionPerformed
        wisudawan_terbaik newWin =  new wisudawan_terbaik ();
        newWin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem12ActionPerformed

    private void jMenuItem15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem15ActionPerformed
        Falkultas newWin =  new Falkultas ();
        newWin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem15ActionPerformed

    private void txtarea2AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtarea2AncestorAdded

    }//GEN-LAST:event_txtarea2AncestorAdded
     public static void main(String[] args) {
       
    
        
        
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Sejarah().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem13;
    private javax.swing.JMenuItem jMenuItem14;
    private javax.swing.JMenuItem jMenuItem15;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea txtarea2;
    // End of variables declaration//GEN-END:variables
}
